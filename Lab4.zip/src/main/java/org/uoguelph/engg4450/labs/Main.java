package org.uoguelph.engg4450.labs;

public class Main {
    public static void main(String[] argvs) {
        String a = "Lab 4";
        System.out.println("Say hello to " + a + "!");
    }
}
